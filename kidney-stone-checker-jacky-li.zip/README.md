## Kidney Stone Checker challenge
### Jacky Li

# How to get started
This challenge was created using React.

In the terminal, run:

```
npm install
```

To run:

```
npm start
```

The page should be accessible at http://localhost:3000
