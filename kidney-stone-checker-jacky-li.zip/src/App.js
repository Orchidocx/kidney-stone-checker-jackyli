import React from 'react';
import Panel from './Panel';
import './css/App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Panel/>
      </header>
    </div>
  );
}

export default App;
